function Tasks() {
  return <div>Tasks</div>;
}

export default Tasks;
